package ListaExercicio;

public class exe04 {

	public static void main(String[] args) {
		for (int i = 1; i <= 100; i++) {
			if (i % 3 == 0) {
				System.out.println("Divisivel por 3: " + i);
			}
		}
	}

}
