package ListaExercicio;

public class exe01 {

	public static void main(String[] args) {
		for (int i = 150; i <= 300; i++) {
			System.out.println("Número: " + i);	}
	}
}
